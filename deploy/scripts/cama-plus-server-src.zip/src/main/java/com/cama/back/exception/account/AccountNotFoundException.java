package com.cama.back.exception.account;

import lombok.Getter;

public class AccountNotFoundException extends RuntimeException {

    @Getter
    private final String loginId;

    public AccountNotFoundException(String loginId) {
        this.loginId = loginId;
    }

    public AccountNotFoundException() {
        loginId = null;
    }

}
