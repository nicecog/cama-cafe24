package com.cama.back.repo.account;


import com.cama.back.domain.account.Account;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface AccountRepository extends JpaRepository<Account, Long> {

    Optional<Account> findByLoginIdAndEnabledAndDropped(String loginId, boolean enabled, boolean dropped);

    Optional<Account> findByEmailAndEnabledAndDropped(String email, boolean enabled, boolean dropped);

    Optional<Account> findByNameAndPhoneAndEnabledAndDropped(String name, String phone, boolean enabled, boolean dropped);

    Optional<Account> findByEmailAndNameAndPhoneAndEnabledAndDropped(String email, String name, String phone, boolean enabled, boolean dropped);

    boolean existsByLoginIdAndEnabledAndDropped(String loginId, boolean enabled, boolean dropped);

    boolean existsByEmailAndEnabledAndDropped(String email, boolean enabled, boolean dropped);

    Optional<Account> findByPatientManagementNumberAndEnabledAndDropped(String patientManagementNumber, boolean enabled, boolean dropped);

    boolean existsByPatientManagementNumberAndEnabledAndDropped(String patientManagementNumber, boolean enabled, boolean dropped);

    Optional<Account> findByPhoneAndEnabledAndDropped(String phone, boolean enabled, boolean dropped);

    boolean existsByPhoneAndEnabledAndDropped(String phone, boolean enabled, boolean dropped);

}
