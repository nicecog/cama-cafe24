package com.cama.back.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.ArrayList;
import java.util.List;

@ConfigurationProperties(prefix = "cama.hosting")
public class CamaHostingProperties {

    /** local: Gabia 디스크, s3: AWS S3 (legacy) */
    private String storageType = "s3";

    /** 업로드 이미지 공개 URL prefix */
    private String imageCdnBaseUrl = "https://d3n20da161n8ia.cloudfront.net";

    /** local 저장 루트 (storage-type=local) */
    private String localStoragePath = "./data/cama-files";

    /** S3 버킷명 (storage-type=s3) */
    private String s3Bucket = "cama-images";

    /** CORS 허용 origin */
    private List<String> corsAllowedOrigins = new ArrayList<>(List.of("*"));

    public String getStorageType() {
        return storageType;
    }

    public void setStorageType(String storageType) {
        this.storageType = storageType;
    }

    public String getLocalStoragePath() {
        return localStoragePath;
    }

    public void setLocalStoragePath(String localStoragePath) {
        this.localStoragePath = localStoragePath;
    }

    public String getImageCdnBaseUrl() {
        return imageCdnBaseUrl;
    }

    public void setImageCdnBaseUrl(String imageCdnBaseUrl) {
        this.imageCdnBaseUrl = imageCdnBaseUrl;
    }

    public String getS3Bucket() {
        return s3Bucket;
    }

    public void setS3Bucket(String s3Bucket) {
        this.s3Bucket = s3Bucket;
    }

    public List<String> getCorsAllowedOrigins() {
        return corsAllowedOrigins;
    }

    public void setCorsAllowedOrigins(List<String> corsAllowedOrigins) {
        this.corsAllowedOrigins = corsAllowedOrigins;
    }
}
